

int get_bitmaps(ALLEGRO_BITMAP **bmp1, ALLEGRO_BITMAP **bmp2, const char *bmp1_config_key, const char *bmp2_config_key, ALLEGRO_CONFIG *cfg);
int get_one_bitmap(ALLEGRO_BITMAP **bmp, const char *config_key, ALLEGRO_CONFIG *cfg);
