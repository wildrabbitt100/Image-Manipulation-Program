

int merge_black_and_white(ALLEGRO_CONFIG *cfg);
