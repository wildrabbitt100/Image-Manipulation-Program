int do_translucency_shading(ALLEGRO_CONFIG *cfg);
