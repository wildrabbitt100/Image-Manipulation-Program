int make_negative(ALLEGRO_CONFIG *cfg);
