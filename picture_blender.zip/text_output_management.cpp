


#include <allegro5/allegro.h>
#include <allegro5/allegro_ttf.h>
#include <iostream>
#include <cmath>
#include <cstring>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>
#include "global.h"
#include "merge_black_and_white.h"

















int make_log_of( const char *string )
{
	
   make_display_target();
   
   
   
   
	
	
	
   return 0;
}
